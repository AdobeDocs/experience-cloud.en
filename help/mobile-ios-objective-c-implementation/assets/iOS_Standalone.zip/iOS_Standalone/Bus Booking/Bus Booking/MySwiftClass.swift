//
//  MySwiftClass.swift
//  Bus Booking
//
//  Created by Anil Bunkar on 27/11/18.
//  Copyright © 2018 Adobe Systems. All rights reserved.
//

import UIKit

class MySwiftClass: NSObject {

}
